package com.example.automotivehistory;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    public TextView tvDetail;
    public ImageView imgAutomotive;
    private Object View;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvDetail = findViewById(R.id.txt_detail);
        Automotive extra = getIntent().getParcelableExtra("objek");
        tvDetail.setText(extra.getDetail());

        imgAutomotive = findViewById(R.id.img_detail);
        imgAutomotive.setImageResource(extra.getPhoto());

    }
}
