package com.example.automotivehistory;

import java.util.ArrayList;

public class AutomotiveData {
    private static String[] heroNames = {
            "Mercedes-Benz",
            "BMW",
            "Porsche",
            "Ferrari",
            "Lancia",
            "Jaguar",
            "Bentley",
            "Mini",
            "Cadillac",
            "Chevrolet"
    };

    private static String[] automotiveDetails = {
            "The two founding fathers of the motor car industry came together when daimler and benz merged in 1926 - the two companies founders had effectively invented the automobile .In addition to being a luxury marque,Mercedes-Benz,the company formed by the merger,has since laid a trail of industry -leading innovation.",
            "Bayerische Motoren Werke (BMW) started life as an aero engine manufacturer in Munich,Germany in 1916,before diversifying into road vehicles.The company had a burst of glory in the 1930s,but it was only in 1961 that BMW really started its journey to become one of the world's finest manufacturer of sport saloons.",
            "A galaxy of legendary road and racing cars had carried the Porsche family name since 1948.There is an unbroken lineage from the earliest 356 to the current 911,spiced with countless race successes,although Porsche's non-sports car models have proven even more popular with audiences worldwide.",
            "The prancing horse of Ferrari has become a fixture at very summit of automotive achievement.Enzo Ferrari's steadfast approach to speed ensured that his team became the most successful of them all in Formula 1 racing,and company has created some of the fastest and most desirable cars ever made.",
            "Now reduced to a subsidiary of Fiat-chrysler,Lancia's long history blended engineering innovation with style in a manner that few companies could rival.Since its creation in 1906 the turin based company,its cars and drivers have enjoyed a glittering career in motor sport,particularly in recent years in international rallying.",
            "in 1922 motorcycle enthusiasts,William Lyons and William Walmsley,went into partnership to build sidecars.Five years later,Lyons designed a stylish body for the austin seven,and just one year on from then his firm moved to coventry from these humble origins the jaguar marque leapt into life.",
            "Today's Bentleys are some of the most lavish cars available,with a decades-long reputation as the pinnacles of the british motor car.The company's founder,Walter Owen Bentley (known as W.O) was an engineer who was concerned about engine performance and reliability when he began his own company in london in 1919.",
            "Mini is now a fully fledged car brand encompassing estates,coupés,sports and racing models,but at its heart lies a revolutionary small car,based on a design conceived by Sir Alec Issigonis in the mid-1950s.Now owned by BMW,the firm continues to build on the little car's success.",
            "The classic car period of 1940-1990 is the era when the cadillac name stood for luxury,Style and power in imposingly large packages.Henry M Leland started the company in 1902 and cadillac became notable for its ability for manufacture high-quality cars on a large scale.",
            "Betweeen 1946 and 1976 Chevrolet was the bestselling brand of car in the US.After it adopted V8 engines in the 1950s chevrolets.like the Bel Air,Corvette,Camaro became synonymous with speed and power,although the range would always be enormous and all-encompassing.",

    };

    private static int[] automotiveImages = {
            R.drawable.mercedesbenz,
            R.drawable.bmw,
            R.drawable.porsche,
            R.drawable.ferrari,
            R.drawable.lancia,
            R.drawable.jaguar,
            R.drawable.bentley,
            R.drawable.mini,
            R.drawable.cadillac,
            R.drawable.chevy
    };

    static ArrayList<Automotive> getListData() {
        ArrayList<Automotive> list = new ArrayList<>();
        for (int position = 0; position < automotiveDetails.length; position++) {
            Automotive automotive = new Automotive();
            automotive.setName(automotiveDetails[position]);
            automotive.setDetail(automotiveDetails[position]);
            automotive.setPhoto(automotiveImages[position]);
            list.add(automotive);
        }
        return list;
    }



}
